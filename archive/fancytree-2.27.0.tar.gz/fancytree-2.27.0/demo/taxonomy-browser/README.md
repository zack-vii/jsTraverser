Taxonomy Browser

Created as a demo for [Fancytree](https://github.com/mar10/fancytree/).
Uses
  - jQuery
  - Bootstrap.js
  - Handlebars.js
  - Fancytree
